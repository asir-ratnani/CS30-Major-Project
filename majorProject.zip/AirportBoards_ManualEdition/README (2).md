Requirements
------------

* Node >= v4.8
* npm >= 2.15

This example uses the npm library node-rest-client.  To install the dependency 
type 'npm install' after cloning the example repository.

What to change
-------------

Substitute your actual username and API key in the app.js file.

Running the example
-------------------
Type 'npm start' from the example root directory.