# Major Project - Beta Testing


### Beta Test #1 - Charlie 
## January 10, 2019

 - Add "main page" that says hit space to change the screen

### Beta Test #2 - Tyler
## January 10, 2019

- Maybe change the font, it can be hard to read with the characters with the colours (yellow can hurt)
- Add something in the empty space
- Maybe add buttons to make it more random person friendly
- Perhaps centre the other text
- A cool thing that you could do would be to be able to imput code, then it will highlight the flight?

### Beta Test #3 - Eimear
## January 21, 2019

 - Make the buttons nicer (AIR PORT BOARDS)
 - Make a back button so you can go back and choose something else
 - Add jazz music to make it more entertaining
 - 