# Major Project History

# November 13, 2018
 - Created prototype Airport Boards- Live Edition (2d-Array Assignment)

# November 16, 2018
 - Completed Airport Boards - Live Edition (2d-Array Assignment)

# December 11, 2018
 - Created Major Project proposal, including need to have list and nice to have list

# December 19/20, 2018
 - Used Regular Expression to set over 500 airline codes to the respected airline name via a Map

# January 9, 2019
 - Completed Airport Boards - Manual Edition

# January 12/13, 2019
 - Completed prototype for Flight Status - Manual Edition via Ident.
 
 - Note: GitHub commit error, wrong date was written in the commit, Should have been Jan 12/13.

# January 15, 2019
 - Completed Flight Status - Manual Edition via Ident
 - Started to create menu to tie it all together.

# January 18, 2019
 - Created menu functionality to switch between Menu Screen, Airport Boards - Manual, and Flight Status - Ident.
 - Still need to design it and add colour.

# January 19, 2019
 - Completed Flight Status - Origin/Destination Edition

# January 21, 2019
 - Completed Menu
 - Completed Major Project


 
