# Major Project

I am planning to create somewhat of a flight status program. 
## Manual entry mode at the beginning (load JSON file everyday)
## Starting with only Saskatoon, moving on to multiple cities afterwards


### Need to Have!!!
 - Flight status using Flight Number. (COMPLETED)
 - Flight status using Origin/Destination (COMPLETED)
 - Departure/Arrivals Board for certain airport (COMPLETED)

### Nice to Have :)
 - Live server data (AIRPORT BOARDS - COMPLETED)
 - Map of flight route?
 - Multiple cities incorporated around the world (COMPLETED)
 - App version / Mobile browser compatible
 - Expand possibilities using flightaware?
 - user input options (PARTIALLY COMPLETED)
 - Menu to tie it all together (PARTIALLY COMPLETED)
