Famirids. A Famicom Liked Typeface with Grid.
--
Make sure you set the normal kerning.
Free for your creation.